import json
import whisper
import os
from pydub import AudioSegment

# Setup whisper model
whisper_model = whisper.load_model("tiny")

# Convert and analyze audio
def convert_and_analyze_audio(input_path, upload_folder):
    audio = AudioSegment.from_file(input_path).set_channels(1).normalize()
    if len(audio) < 500:
        raise Exception("Audio too short or empty")

    base = os.path.splitext(os.path.basename(input_path))[0]
    wav_path = os.path.join(upload_folder, base + "_converted.wav")
    json_path = os.path.join(upload_folder, base + "_converted.json")

    if not os.path.exists(wav_path) or not os.path.exists(json_path):
        audio.export(wav_path, format="wav")
        result = whisper_model.transcribe(wav_path, word_timestamps=True, language="en")
        if not result.get("segments"):
            raise Exception("No speech segments found")
        timestamps = [(word["start"], word["end"]) for seg in result["segments"] for word in seg.get("words", [])]
        with open(json_path, "w") as f:
            json.dump(timestamps, f)

    return wav_path, json_path, round(audio.duration_seconds, 2)
