# settings.py
import os
import json

SETTINGS_FILE = "settings.json"

def load_settings():
    if os.path.exists(SETTINGS_FILE):
        with open(SETTINGS_FILE, "r") as f:
            return json.load(f)
    return {
        "volume": 1.0,
        "pwm": {"mouth": 100, "body": 60, "tail": 50},
        "smoothing": 5,
        "favorites": [],
        "autoplay": False
    }

def save_settings(settings):
    with open(SETTINGS_FILE, "w") as f:
        json.dump(settings, f)
