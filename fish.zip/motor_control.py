# motor control logic
def move_motor(): pass